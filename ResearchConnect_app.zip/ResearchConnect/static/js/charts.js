/* charts.js - draws every simple bar chart with Plotly.js.
   Python sends {labels, values, orientation, x_title, y_title} in a data-chart attribute. */
(function () {
  var TEXT = "#A2AAC0", GRID = "rgba(162,170,192,0.14)", BAR = "#A78BFA";

  function short(label) { return label.length > 30 ? label.slice(0, 29) + "\u2026" : label; }

  function drawBar(el, cfg) {
    var horizontal = cfg.orientation === "h";
    var shown = cfg.labels.map(short);
    var trace = {
      type: "bar",
      orientation: cfg.orientation,
      marker: { color: BAR, line: { color: "#C4B5FD", width: 0 } },
      hovertext: cfg.labels,
      hovertemplate: "%{hovertext}: %{" + (horizontal ? "x" : "y") + "}<extra></extra>"
    };
    var countAxis = { gridcolor: GRID, zeroline: false, rangemode: "tozero", tickformat: "d",
                      title: { text: horizontal ? cfg.x_title : cfg.y_title } };
    var labelAxis = { type: "category", gridcolor: "rgba(0,0,0,0)", automargin: true,
                      title: { text: horizontal ? cfg.y_title : cfg.x_title } };
    if (horizontal) {
      trace.x = cfg.values; trace.y = shown;
      labelAxis.autorange = "reversed";          // biggest bar on top
    } else {
      trace.x = shown; trace.y = cfg.values;
    }
    var layout = {
      paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "rgba(0,0,0,0)",
      font: { family: "DM Sans, sans-serif", color: TEXT, size: 12 },
      margin: { l: 10, r: 16, t: 8, b: 10 },
      xaxis: horizontal ? countAxis : labelAxis,
      yaxis: horizontal ? labelAxis : countAxis,
      bargap: 0.35
    };
    Plotly.newPlot(el, [trace], layout, { displayModeBar: false, responsive: true });
  }

  document.querySelectorAll("[data-chart]").forEach(function (el) {
    try { drawBar(el, JSON.parse(el.getAttribute("data-chart"))); }
    catch (err) { el.textContent = "This chart could not be drawn."; }
  });
})();
